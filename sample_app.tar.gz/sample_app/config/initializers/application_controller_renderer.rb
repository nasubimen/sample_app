# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end


Refile.secret_key = '1f2629a64843ef87fc744ec3cc7953db5a823e5b761b09b0175b8f7e25cfc242fce5fe8eaedc726943df2f5b5172792fabe63549e5917dd7c7b72eaa1c3783b8'